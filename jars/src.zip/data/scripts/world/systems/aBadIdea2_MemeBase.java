package data.scripts.world.systems;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
//import com.fs.starfarer.api.impl.campaign.econ.impl.HeavyIndustry;
import com.fs.starfarer.api.impl.campaign.ids.*;
import com.fs.starfarer.api.impl.campaign.procgen.NebulaEditor;
//import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
//import com.fs.starfarer.api.impl.campaign.procgen.themes.SalvageSpecialAssigner;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarGenDataSpec;
import com.fs.starfarer.api.impl.campaign.terrain.HyperspaceTerrainPlugin;
//import com.fs.starfarer.api.impl.campaign.terrain.EventHorizonPlugin;
import com.fs.starfarer.api.impl.campaign.terrain.StarCoronaTerrainPlugin;
import com.fs.starfarer.api.util.Misc;
import data.utils.aBadIdea2.aBadIdea2Util;

import java.awt.*;
import java.util.ArrayList;
import java.util.Arrays;

//import static com.fs.starfarer.api.impl.campaign.terrain.DebrisFieldTerrainPlugin.DebrisFieldParams;
//import static com.fs.starfarer.api.impl.campaign.terrain.DebrisFieldTerrainPlugin.DebrisFieldSource;
import static data.scripts.world.aBadIdea2_WorldGen.addMarketplace;

public class aBadIdea2_MemeBase {
    public void generate(SectorAPI sector) {
        //create a star system
        StarSystemAPI system = sector.createStarSystem("Ischys");
        //set its location
        system.getLocation().set(20000f, 10000f);
        //set background image
        system.setBackgroundTextureFilename("graphics/backgrounds/background5.jpg");

        //the star
        PlanetAPI star = system.initStar("aBadIdea2_Ischys", "black_hole", 500f, 0f);
        star.getSpec().setBlackHole(true);
        system.addTag(Tags.HAS_CORONAL_TAP);
        //background light color
        system.setLightColor(new Color(228, 180, 255));
        StarCoronaTerrainPlugin coronaPlugin = Misc.getCoronaFor(star);
        if (coronaPlugin != null) {
            system.removeEntity(coronaPlugin.getEntity());
        }

        StarGenDataSpec starData = (StarGenDataSpec) Global.getSettings().getSpec(StarGenDataSpec.class, star.getSpec().getPlanetType(), false);
        float corona = (float)((double)star.getRadius() * ((double)starData.getCoronaMult() + (double)starData.getCoronaVar() * (Math.random() - 0.5D)));
        if (corona < starData.getCoronaMin()) {
            corona = starData.getCoronaMin();
        }

        SectorEntityToken eventHorizon = system.addTerrain("event_horizon", new StarCoronaTerrainPlugin.CoronaParams(star.getRadius() + corona, (star.getRadius() + corona) / 2.0F, star, starData.getSolarWind(), 0.0F, Math.max(starData.getCrLossMult(), 25.0F)));
        eventHorizon.setCircularOrbit(star, 0.0F, 0.0F, 100.0F);

        //make asteroid belt surround it
        system.addAsteroidBelt(star, 200, 2200f, 500f, 180, 360, Terrain.ASTEROID_BELT, "");

        SectorEntityToken aBadIdea2_shunt = system.addCustomEntity(null, null, "coronal_tap", "neutral");
        aBadIdea2_shunt.setCircularOrbitWithSpin(star, 180f, 0f, 1f, -1000f, 1000f);
        aBadIdea2_shunt.setDiscoverable(true);
        aBadIdea2_shunt.setSensorProfile(500f);

        //a new planet for people
        PlanetAPI aBadIdea2_planet_fat_dab = system.addPlanet("aBadIdea2_planet_fat_dab", star, aBadIdea2Util.getStarSystemsString("planet_name_fat_dab"), "jungle", 215, 250f, 7000f, 135f);
        aBadIdea2_planet_fat_dab.setCircularOrbitWithSpin(star, 215f, 7000f, 135f, -360f, 360f);

        //a new market for planet
        MarketAPI aBadIdea2_planet_fat_dabMarket = addMarketplace("aBadIdea2_philpocalypse", aBadIdea2_planet_fat_dab, null
                , aBadIdea2_planet_fat_dab.getName(), 6,
                new ArrayList<>(
                        Arrays.asList(
                                Conditions.POPULATION_6,
                                Conditions.JUNGLE,
                                Conditions.DARK,
                                Conditions.FARMLAND_BOUNTIFUL,
                                Conditions.ORGANICS_ABUNDANT,
                                Conditions.RUINS_VAST,
                                Conditions.HIGH_GRAVITY
                        )),
                new ArrayList<>(
                        Arrays.asList(
                                Submarkets.GENERIC_MILITARY,
                                Submarkets.SUBMARKET_BLACK,
                                Submarkets.SUBMARKET_OPEN,
                                Submarkets.SUBMARKET_STORAGE
                        )),
                new ArrayList<>(
                        Arrays.asList(
                                Industries.POPULATION,
                                Industries.MEGAPORT,
                                Industries.STARFORTRESS,
                                Industries.FARMING,
                                Industries.PATROLHQ,
                                Industries.ORBITALWORKS,
                                Industries.WAYSTATION,
                                Industries.TECHMINING,
                                Industries.HEAVYBATTERIES,
                                Industries.MINING
                        )),
                0.3f,
                true,
                true);
        //make a custom description which is specified in descriptions.csv
        aBadIdea2_planet_fat_dab.setCustomDescriptionId("aBadIdea2_planet_fat_dab");
        //give the orbital works a gamma core
        aBadIdea2_planet_fat_dabMarket.getIndustry(Industries.ORBITALWORKS).setAICoreId(Commodities.BETA_CORE);
        //and give it a nanoforge
        //((HeavyIndustry) fat_dabMarket.getIndustry(Industries.ORBITALWORKS)).setNanoforge(new SpecialItemData(Items.CORRUPTED_NANOFORGE, null));

        PlanetAPI aBadIdea2_planet_shrinkage = system.addPlanet("aBadIdea2_planet_shrinkage", star, aBadIdea2Util.getStarSystemsString("planet_name_shrinkage"), "cryovolcanic", 90, 90, 3500f, 30);

        MarketAPI aBadIdea2_planet_shrinkageMarket = addMarketplace("aBadIdea2_philpocalypse", aBadIdea2_planet_shrinkage, null
                , aBadIdea2_planet_shrinkage.getName(), 5,
                new ArrayList<>(
                        Arrays.asList(
                                Conditions.POPULATION_5,
                                Conditions.ORE_RICH,
                                Conditions.RARE_ORE_ABUNDANT,
                                Conditions.DARK,
                                Conditions.EXTREME_TECTONIC_ACTIVITY,
                                Conditions.VERY_COLD,
                                Conditions.LOW_GRAVITY
                        )),
                new ArrayList<>(
                        Arrays.asList(
                                Submarkets.SUBMARKET_BLACK,
                                Submarkets.SUBMARKET_OPEN,
                                Submarkets.SUBMARKET_STORAGE
                        )),
                new ArrayList<>(
                        Arrays.asList(
                                Industries.POPULATION,
                                Industries.SPACEPORT,
                                Industries.BATTLESTATION,
                                Industries.HIGHCOMMAND,
                                Industries.MINING,
                                Industries.LIGHTINDUSTRY
                        )),
                0.3f,
                false,
                true);
        aBadIdea2_planet_shrinkage.setCustomDescriptionId("aBadIdea2_planet_shrinkage");
        aBadIdea2_planet_shrinkageMarket.getIndustry(Industries.HIGHCOMMAND).setAICoreId(Commodities.BETA_CORE);


        PlanetAPI aBadIdea2_meatball = system.addPlanet("aBadIdea2_meatball", star, "Spicy Meatball", "lava", 110, 90, 1250f, 15f);
        Misc.initConditionMarket(aBadIdea2_meatball);
        aBadIdea2_meatball.getMarket().addCondition(Conditions.EXTREME_WEATHER);
        aBadIdea2_meatball.getMarket().addCondition(Conditions.POOR_LIGHT);
        aBadIdea2_meatball.getMarket().addCondition(Conditions.EXTREME_TECTONIC_ACTIVITY);
        aBadIdea2_meatball.getMarket().addCondition(Conditions.VERY_HOT);
        aBadIdea2_meatball.getMarket().addCondition(Conditions.RARE_ORE_ULTRARICH);
        aBadIdea2_meatball.getMarket().addCondition(Conditions.ORE_ULTRARICH);
        aBadIdea2_meatball.getMarket().addCondition(Conditions.RUINS_VAST);
        aBadIdea2_meatball.setCustomDescriptionId("aBadIdea2_planet_meatball");


        PlanetAPI aBadIdea2_fartcloud = system.addPlanet("aBadIdea2_fartcloud", star, "Garlic", "gas_giant", 110, 350, 12000f, 15f);
        Misc.initConditionMarket(aBadIdea2_fartcloud);
        aBadIdea2_fartcloud.getMarket().addCondition(Conditions.EXTREME_WEATHER);
        aBadIdea2_fartcloud.getMarket().addCondition(Conditions.HIGH_GRAVITY);
        aBadIdea2_fartcloud.getMarket().addCondition(Conditions.VERY_COLD);
        aBadIdea2_fartcloud.getMarket().addCondition(Conditions.VOLATILES_ABUNDANT);
        aBadIdea2_fartcloud.getMarket().addCondition(Conditions.ORGANICS_ABUNDANT);
        aBadIdea2_fartcloud.getMarket().addCondition(Conditions.DARK);
        aBadIdea2_fartcloud.getMarket().addCondition(Conditions.IRRADIATED);
        aBadIdea2_fartcloud.getMarket().addCondition(Conditions.DENSE_ATMOSPHERE);
        aBadIdea2_fartcloud.getMarket().addCondition(Conditions.TOXIC_ATMOSPHERE);
        aBadIdea2_fartcloud.setCustomDescriptionId("aBadIdea2_planet_fartcloud");

        // generates hyperspace destinations for in-system jump points
        system.autogenerateHyperspaceJumpPoints(true, true);

        //custom entities
        SectorEntityToken aBadIdea2_relay = system.addCustomEntity(null, "Ischyss Buoy", "nav_buoy", "aBadIdea2_philpocalypse");
        aBadIdea2_relay.setCircularOrbit(star, 90f, 6000f, 20f);
        SectorEntityToken aBadIdea2_buoy = system.addCustomEntity(null, "Ischys Array", "sensor_array", "aBadIdea2_philpocalypse");
        aBadIdea2_buoy.setCircularOrbit(star, 180f, 5750f, 15f);
        SectorEntityToken aBadIdea2_array = system.addCustomEntity(null, "Ischys Relay", "comm_relay", "aBadIdea2_philpocalypse");
        aBadIdea2_array.setCircularOrbit(star, 270f, 5500f, 10f);

        //nebula
        SectorEntityToken aBadIdea2_Nebula = Misc.addNebulaFromPNG("data/campaign/terrain/nebula_test.png", 0, 0, system, "terrain", "nebula_amber", 4, 4, StarAge.AVERAGE);
        /*
        // Debris
        DebrisFieldParams params = new DebrisFieldParams(
                150f, // field radius - should not go above 1000 for performance reasons
                1f, // density, visual - affects number of debris pieces
                10000000f, // duration in days
                0f); // days the field will keep generating glowing pieces
        params.source = DebrisFieldSource.MIXED;
        params.baseSalvageXP = 500; // base XP for scavenging in field
        SectorEntityToken debris = Misc.addDebrisField(system, params, StarSystemGenerator.random);
        SalvageSpecialAssigner.assignSpecialForDebrisField(debris);

        // makes the debris field always visible on map/sensors and not give any xp or notification on being discovered
        debris.setSensorProfile(null);
        debris.setDiscoverable(null);

        // makes it discoverable and give 200 xp on being found
        // sets the range at which it can be detected (as a sensor contact) to 2000 units
        // commented out.
        debris.setDiscoverable(true);
        debris.setDiscoveryXP(200f);
        debris.setSensorProfile(1f);
        debris.getDetectedRangeMod().modifyFlat("gen", 2000);

        debris.setCircularOrbit(star
        , 45 + 10, 1600, 250);*/
        //Finally cleans up hyperspace
        cleanup(system);

    }

    //Learning from Tart scripts
    //Clean nearby Nebula
    private void cleanup(StarSystemAPI system) {
        HyperspaceTerrainPlugin plugin = (HyperspaceTerrainPlugin) Misc.getHyperspaceTerrain().getPlugin();
        NebulaEditor editor = new NebulaEditor(plugin);
        float minRadius = plugin.getTileSize() * 2f;

        float radius = system.getMaxRadiusInHyperspace();
        editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius * 0.5f, 0, 360f);
        editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius, 0, 360f, 0.25f);
    }
}
